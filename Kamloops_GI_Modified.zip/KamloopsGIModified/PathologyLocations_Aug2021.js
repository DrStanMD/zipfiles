/***********************************************************************
*   LOCATION FUNCTION
*   PM Sep 2017
************************************************************************/

function SetLocation(i) {
	switch(i) {
		default:
		LocationSite = "";
     	subject = "";
		break;

		case "Burnaby Hospital":
		LocationSite = 'Burnaby Hospital \n3935 Kincaid St, Burnaby, BC, V5G 2X6 \nPh: 604-412-6245 \nFax: 604-412-2806';
		subject = i; 
		break;

		case "Surrey Memorial Hospital":
		LocationSite = 'Surrey Memorial Hospital \n13750 96th Ave \nSurrey, BC, V3V 1Z2 \nPh: 604-588-3384\nFax: 604-585-5562';
		subject = i; 
		break;

		case "Royal Columbian Hospital":
		LocationSite = 'Royal Columbian Hospital \n330 E Columbia St, New Westminster, BC, V3L 3W7 \nPh: 604-520-4325 \nFax: 604-520-4409';
		subject = i; 
		break;

		case "Abbotsford Regional Hospital":
		LocationSite = 'Abbotsford Regional Hospital and Cancer Centre \n32900 Marshall Rd, Abbotsford, BC, V2S 0C2 \nPh: 604-851-4700 loc 646545 \nFax: 604-851-4858';
		subject = i; 
		break;
		}

	document.FormName.LocationSite.value = LocationSite;
	document.FormName.subject.value = subject; 
	}